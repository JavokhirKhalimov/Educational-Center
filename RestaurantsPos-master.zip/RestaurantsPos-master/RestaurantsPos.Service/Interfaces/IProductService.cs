﻿
using RestaurantsPos.Shared.Models.DbModels;
using RestaurantsPos.Shared.Models.PostModels;

namespace RestaurantsPos.Service.Interfaces;

public interface IProductService
{
    Task<Product> AddProductAsync(ProductPostModel productPostModel);
    Task<Product> UpdateProductByIdAsync(Guid productId, ProductPostModel productPostModel);
    Task<Product> DeleteProductByIdAsync(Guid productId);
    Task<Product> GetProductByIdAsync(Guid productId);
    Task<IEnumerable<Product>> GetAllProductsAsync(Guid restuarantId);


    // product type
    Task<ProductType> AddProductTypeAsync(ProductType productType);
    Task<ProductType> UpdateProductTypeAsync(ProductType productType);
    Task<ProductType> DeleteProductTypeByIdAsync(Guid productTypeId);
    Task<ProductType> GetProductTypeByIdAsync(Guid productTypeId);
    Task<IEnumerable<ProductType>> GetAllProductTypesAsync(Guid restuarantId);
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace RestaurantsPos.Shared.Models.DbModels;

public class Stol
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid StolId { get; set; }

    [ForeignKey(nameof(Restuarant))]
    public Guid RestuarantId { get; set; }

    [NotNull]
    public int StolNumber { get; set; }
    public virtual ICollection<ProductStol> ProductStols { get; set; }
}

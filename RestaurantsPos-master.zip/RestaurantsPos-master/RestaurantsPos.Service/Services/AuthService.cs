﻿using RestaurantsPos.Service.Interfaces;
using RestaurantsPos.Shared.Models.DbModels;

namespace RestaurantsPos.Service.Services;

public class AuthService : IAuthService
{
    public string Sign_In(Login restaurant_signIn)
    {
        throw new NotImplementedException();
    }

    public string Sign_Up(Restuarant restuarant_signUp)
    {
        throw new NotImplementedException();
    }
}

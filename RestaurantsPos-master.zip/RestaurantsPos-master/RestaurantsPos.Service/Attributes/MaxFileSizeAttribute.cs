﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantsPos.Service.Attributes
{
    public class MaxFileSizeAttribute:ValidationAttribute
    {
        private readonly int _max_size;

        public MaxFileSizeAttribute(int max_size)
        {
            _max_size = max_size;
        }

        protected override ValidationResult IsValid(
            object value, ValidationContext validationContext)
        {
            var file = value as IFormFile;
            if (file != null)
            {
                if (file.Length > _max_size)
                {
                    return new ValidationResult(GetErrorMessage());
                }
            }

            return ValidationResult.Success;
        }

        public string GetErrorMessage()
        {
            return $"Kechirasiz {_max_size} bytedan katta file yuklash mumkin emas!";
        }
    }
}

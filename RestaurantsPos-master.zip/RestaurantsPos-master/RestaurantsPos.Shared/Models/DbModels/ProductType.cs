﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RestaurantsPos.Shared.Models.DbModels;

public class ProductType
{

    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid ProductTypeId { get; set; }

    [ForeignKey(nameof(Restuarant))]
    public Guid RestuarantId { get; set; }

    public virtual ICollection<Product> Products { get; set; }

    [Required, MaxLength(100)]
    public string ProductTypeName { get; set; }
}

﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using RestaurantsPos.Service.Data;
using RestaurantsPos.Service.Interfaces;
using RestaurantsPos.Shared.Models.DbModels;
using RestaurantsPos.Shared.Models.PostModels;


namespace RestaurantsPos.Service.Services;

public class ProductService : IProductService
{
    private readonly DataContext _dbContext;
    private readonly IWebHostEnvironment webHostEnvironment;
    
    
    public ProductService(DataContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<Product> AddProductAsync(ProductPostModel productPostModel)
    {
        //Product product = new Product();
        //product.ProductName = productPostModel.ProductName;
        //product.Cost = productPostModel.Cost;

        throw new NotImplementedException();
        
        


    }

    public async Task<ProductType> AddProductTypeAsync(ProductType productType)
    {
        productType.Products = null;
        await _dbContext.AddAsync(productType);
        await _dbContext.SaveChangesAsync();
        return productType;
    }

    public Task<Product> DeleteProductByIdAsync(Guid productId)
    {
        throw new NotImplementedException();
    }

    public async Task<ProductType> DeleteProductTypeByIdAsync(Guid productTypeId)
    {
        var pt = await this.GetProductTypeByIdAsync(productTypeId);
        _dbContext.ProductTypes.Remove(pt);
        await _dbContext.SaveChangesAsync();
        return pt;
    }

    public async Task<IEnumerable<Product>> GetAllProductsAsync(Guid restuarantId)
    {
        var products = _dbContext.Products
            .Where(p => p.RestuarantId == restuarantId)
            .ToListAsync();
        return await products;
    }

    public async Task<IEnumerable<ProductType>> GetAllProductTypesAsync(Guid restuarantId)
    {
        var pts = _dbContext.ProductTypes
            .Where(pt => pt.RestuarantId == restuarantId)
            .ToListAsync();
        return await pts;
    }

    public async Task<Product> GetProductByIdAsync(Guid productId)
    {
        var product = await _dbContext.Products
            .Include(p => p.ProductStols)
            .FirstOrDefaultAsync(p => p.ProductId == productId);
        if(product is null)
            throw new KeyNotFoundException(nameof(product));
        return product;
    }

    public async Task<ProductType> GetProductTypeByIdAsync(Guid productTypeId)
    {
        var productType = await _dbContext.ProductTypes
            .Include(pt => pt.Products)
            .FirstOrDefaultAsync(pt => pt.ProductTypeId == productTypeId);
        if(productType is null)
            throw new KeyNotFoundException(nameof(productType));
        return productType;
    }

    public Task<Product> UpdateProductByIdAsync(Guid productId, ProductPostModel productPostModel)
    {
        throw new NotImplementedException();
    }

    public Task<ProductType> UpdateProductTypeAsync(ProductType productType)
    {
        throw new NotImplementedException();
    }
}

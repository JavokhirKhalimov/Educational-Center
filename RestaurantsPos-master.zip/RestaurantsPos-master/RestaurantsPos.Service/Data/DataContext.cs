﻿
using Microsoft.EntityFrameworkCore;
using RestaurantsPos.Shared.Models.DbModels;

namespace RestaurantsPos.Service.Data;

public class DataContext : DbContext
{
	public DataContext(DbContextOptions<DataContext> options)
		:base(options) {}

	public DbSet<Product> Products { get; set; }
	public DbSet<Stol> Stols { get; set; }
	public DbSet<ProductType> ProductTypes { get; set; }
	public DbSet<ProductStol> ProductStols { get; set; }

	public DbSet<Restuarant> Restuarants { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
		modelBuilder.Entity<Restuarant>()
			.HasIndex(res => new
			{
				res.Username,
				res.Phone
			})
			.IsUnique(true);
    }
}

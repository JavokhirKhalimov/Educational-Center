﻿using RestaurantsPos.Shared.Models.DbModels;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;


namespace RestaurantsPos.Shared.Models.PostModels;

public class ProductPostModel
{
    [ForeignKey(nameof(ProductType))]
    public Guid ProductTypeId { get; set; }

    [ForeignKey(nameof(Restuarant))]
    public Guid RestuarantId { get; set; }

    [Required, MaxLength(100)]
    public string ProductName { get; set; }

    [Column(TypeName = "money")]
    public decimal Cost { get; set; }

    
    public IFormFile Image { get; set; }
}

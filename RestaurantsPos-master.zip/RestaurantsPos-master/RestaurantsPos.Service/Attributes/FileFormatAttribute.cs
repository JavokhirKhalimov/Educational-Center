﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantsPos.Service.Attributes
{
    public class FileFormatAttribute:ValidationAttribute
    {
        private readonly IEnumerable<string> _formats;

        public FileFormatAttribute(params string[] formats)
        {
            _formats = formats;
        }
        protected override ValidationResult 
            IsValid(object? value, ValidationContext validationContext)
        {
            var file = value as IFormFile;
            if(file != null)
            {
                var fileFormat=Path.GetExtension(file.FileName);
                if (!_formats.Contains(fileFormat.ToLower()))
                {
                    return new ValidationResult(GetErrorMessage());
                }
            }
            return ValidationResult.Success;
        }

        public string GetErrorMessage()
        {
            return @$"Iltimos faqat ""{string.Join(@""", """, _formats)}"" formatlarda rasm yuklang!";
        }
    }
}

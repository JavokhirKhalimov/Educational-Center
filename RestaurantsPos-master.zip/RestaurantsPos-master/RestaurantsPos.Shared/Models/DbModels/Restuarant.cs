﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantsPos.Shared.Models.DbModels;

public class Restuarant
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public Guid RestuarantId { get; set; }

    [Required, MinLength(4), MaxLength(150)]
    public string Name { get; set; }

    [Phone]
    public string Phone { get; set; }

    [Required, MinLength(8), MaxLength(32)]
    public string Username { get; set; }

    [Required, MinLength(8)]
    public string Password { get; set; }

    public string? LogoUrl { get; set; }


    public virtual ICollection<Stol> Stols { get; set; }
    public virtual ICollection<Product> Products { get; set; }
    public virtual ICollection<ProductType> ProductTypes { get; set; }

}

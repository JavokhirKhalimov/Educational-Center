﻿using RestaurantsPos.Shared.Models.DbModels;

namespace RestaurantsPos.Service.Interfaces;

public interface IAuthService
{
    public string Sign_Up(Restuarant restuarant_signUp);

    public string Sign_In(Login restaurant_signIn);
}

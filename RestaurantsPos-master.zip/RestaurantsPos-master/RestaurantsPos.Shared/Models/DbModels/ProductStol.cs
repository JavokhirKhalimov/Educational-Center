﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace RestaurantsPos.Shared.Models.DbModels;

public class ProductStol
{
    [Key]
    public int Id { get; set; }

    [ForeignKey(nameof(Restuarant))]
    public Guid RestuarantId { get; set; }

    [ForeignKey(nameof(Stol))]
    public Guid StolId { get; set; }

    [ForeignKey(nameof(StolId))]
    public virtual Stol Stol { get; set; }

    [ForeignKey(nameof(Product))]
    public Guid ProductId { get; set; }

    [ForeignKey(nameof(ProductId))]
    public virtual Product Product { get; set; }

    [DefaultValue(false)]
    public bool IsSold { get; set; }

    public DateTime SoldDate { 
        get
        { 
            return _soldDate.HasValue ?
                _soldDate.Value : DateTime.Now;
        }
        set
        {
            _soldDate = value;
        }
    }

    private DateTime? _soldDate = null;
}

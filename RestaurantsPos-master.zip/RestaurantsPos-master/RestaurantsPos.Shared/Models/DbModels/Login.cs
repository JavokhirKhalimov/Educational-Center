﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantsPos.Shared.Models.DbModels
{
    public class Login
    {
        [ForeignKey(nameof(Restuarant))]
        public Guid SignIn_Id { get; set; }

        [ForeignKey(nameof(SignIn_Id))]
        public Restuarant Restuarant { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}

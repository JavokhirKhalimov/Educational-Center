﻿namespace RestaurantsPos.Service
{
    public class Class3
    {

    }
}